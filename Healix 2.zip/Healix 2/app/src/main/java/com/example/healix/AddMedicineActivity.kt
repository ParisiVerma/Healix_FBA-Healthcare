package com.example.healix

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

class AddMedicineActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_add_medicine)

        // 🔔 Permission
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1
                )
            }
        }

        val medName = findViewById<EditText>(R.id.medName)
        val dosage = findViewById<EditText>(R.id.dosage)
        val frequency = findViewById<Spinner>(R.id.frequency)
        val generateBtn = findViewById<Button>(R.id.generateBtn)
        val scheduleText = findViewById<TextView>(R.id.scheduleText)

        val options = arrayOf("Once a day", "Twice a day", "Thrice a day")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        frequency.adapter = adapter

        generateBtn.setOnClickListener {

            val name = medName.text.toString()
            val dose = dosage.text.toString()
            val freq = frequency.selectedItem.toString()

            if (name.isEmpty() || dose.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 🧠 GENERATE SCHEDULE
            val times = when (freq) {
                "Once a day" -> listOf("9:00 AM")
                "Twice a day" -> listOf("9:00 AM", "9:00 PM")
                "Thrice a day" -> listOf("8:00 AM", "2:00 PM", "8:00 PM")
                else -> listOf()
            }

            val schedule = "$name ($dose)\n" + times.joinToString(", ")
            scheduleText.text = schedule

            // 💾 SAVE DATA
            val sharedPref = SessionManager.dataPrefs(this)
            val existing = sharedPref.getString("medList", "") ?: ""
            val updated = if (existing.isEmpty()) schedule else "$existing||$schedule"
            sharedPref.edit().putString("medList", updated).apply()

            Toast.makeText(this, "Medicine Saved!", Toast.LENGTH_SHORT).show()

            // 🔔 WORKMANAGER NOTIFICATION (10 sec delay)
            val data = Data.Builder()
                .putString("medName", name)
                .build()

            val workRequest = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInputData(data)
                .setInitialDelay(10, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(this).enqueue(workRequest)
            finish()
        }
    }
}