package com.example.healix

import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ✅ Use simple button (safe)
        val btn = Button(this)
        btn.text = "Open Symptom Checker"

        btn.setOnClickListener {
            startActivity(Intent(this, SymptomCheckerActivity::class.java))
        }

        setContentView(btn)
    }
}