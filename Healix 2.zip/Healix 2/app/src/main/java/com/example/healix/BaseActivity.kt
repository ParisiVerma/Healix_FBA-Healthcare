package com.example.healix

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity

/**
 * Any screen that shows personal health data extends this instead of
 * AppCompatActivity directly. It makes sure nobody can land on a data
 * screen (medicine list, profile, etc.) without being signed in -
 * e.g. if the process was killed and restarted straight into an inner
 * activity, or another app tries to deep-link into one.
 */
abstract class BaseActivity : AppCompatActivity() {

    override fun onStart() {
        super.onStart()
        if (!SessionManager.isLoggedIn) {
            startActivity(
                Intent(this, WelcomeActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            finish()
        }
    }
}
