package com.example.healix

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class SignUpActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        auth = FirebaseAuth.getInstance()

        val name = findViewById<EditText>(R.id.name)
        val age = findViewById<EditText>(R.id.age)
        val gender = findViewById<EditText>(R.id.gender)
        val weight = findViewById<EditText>(R.id.weight)
        val height = findViewById<EditText>(R.id.height)
        val blood = findViewById<EditText>(R.id.blood)
        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val signUpBtn = findViewById<Button>(R.id.signUpBtn)
        val goToLoginLink = findViewById<TextView>(R.id.goToLoginLink)

        // A ProgressBar isn't in this layout by default; reuse the button's
        // enabled state to prevent double-submits while the request is in flight.

        signUpBtn.setOnClickListener {
            val userName = name.text.toString().trim()
            val userAge = age.text.toString().trim()
            val userGender = gender.text.toString().trim()
            val userWeight = weight.text.toString().trim()
            val userHeight = height.text.toString().trim()
            val userBlood = blood.text.toString().trim()
            val userEmail = email.text.toString().trim()
            val userPassword = password.text.toString()

            if (userName.isEmpty()) {
                name.error = "Enter name"
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()) {
                email.error = "Invalid email"
                return@setOnClickListener
            }

            if (userPassword.length < 6) {
                password.error = "Password must be 6+ characters"
                return@setOnClickListener
            }

            signUpBtn.isEnabled = false

            auth.createUserWithEmailAndPassword(userEmail, userPassword)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // Save the profile fields locally, namespaced to this
                        // brand-new Firebase UID.
                        SessionManager.userPrefs(this).edit()
                            .putString("username", userName)
                            .putString("age", userAge)
                            .putString("gender", userGender)
                            .putString("weight", userWeight)
                            .putString("height", userHeight)
                            .putString("blood", userBlood)
                            .putString("email", userEmail)
                            .apply()

                        startActivity(Intent(this, ProfileActivity::class.java))
                        finish()
                    } else {
                        signUpBtn.isEnabled = true
                        val message = task.exception?.localizedMessage
                            ?: "Sign up failed. Please try again."
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    }
                }
        }

        goToLoginLink.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
