package com.example.healix

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices


class MedicalStoresActivity : BaseActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient


   
    private lateinit var enableLocationBtn: Button


    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            loadNearbyPharmacies()
        } else {
            showStatus("Location permission is needed to find pharmacies near you.")
            enableLocationBtn.visibility = View.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medical_stores)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        progress = findViewById(R.id.storesProgress)
        statusText = findViewById(R.id.storesStatusText)
        enableLocationBtn = findViewById(R.id.enableLocationBtn)
        recyclerView = findViewById(R.id.pharmacyRecyclerView)

        adapter = PharmacyAdapter(onDirectionsClick = { pharmacy -> openDirections(pharmacy) })
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<Button>(R.id.findOnMapBtn).setOnClickListener {
            openPharmacySearchOnMap()
        }

        findViewById<ImageButton>(R.id.refreshBtn).setOnClickListener {
            checkPermissionAndLoad()
        }

        enableLocationBtn.setOnClickListener {
            requestLocationPermission()
        }

        checkPermissionAndLoad()
    }

    private fun checkPermissionAndLoad() {
        if (hasLocationPermission()) {
            enableLocationBtn.visibility = View.GONE
            loadNearbyPharmacies()
        } else {
            requestLocationPermission()
        }
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        locationPermissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    @Suppress("MissingPermission")
    private fun loadNearbyPharmacies() {
        showLoading(true)
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location == null) {
                    showLoading(false)
                    showStatus("Couldn't get your current location. Make sure location/GPS is turned on and try again.")
                    return@addOnSuccessListener
                }
                fetchPharmacies(location.latitude, location.longitude)
            }
            .addOnFailureListener {
                showLoading(false)
                showStatus("Couldn't get your current location: ${it.localizedMessage}")
            }
    }
    private fun fetchPharmacies(latitude: Double, longitude: Double) {
        showLoading(false)

        try {
            val uri = "geo:$latitude,$longitude?q=pharmacy".toUri()
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        } catch (_: Exception) {
            val webUri =
                "https://www.google.com/maps/search/pharmacy/@$latitude,$longitude,15z".toUri()
            startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    private fun fetchPharmacies(latitude: Double, longitude: Double) {
        lifecycleScope.launch {
            val result = PlacesApiClient.findNearbyPharmacies(latitude, longitude)
            showLoading(false)

            result.onSuccess { pharmacies ->
                if (pharmacies.isEmpty()) {
                    showStatus("No pharmacies found within 3 km. Try the map search above.")
                } else {
                    statusText.visibility = View.GONE
                }
                adapter.submitList(pharmacies)
            }.onFailure { error ->
                adapter.submitList(emptyList())
                showStatus(error.localizedMessage ?: "Couldn't load nearby pharmacies.")
            }
        }
    }

    private fun openDirections(pharmacy: Pharmacy) {
        try {
            val gmmIntentUri =
                "geo:${pharmacy.latitude},${pharmacy.longitude}?q=${pharmacy.latitude},${pharmacy.longitude}(${pharmacy.name})".toUri()
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)
        } catch (_: Exception) {
            val fallbackUri =
                "https://www.google.com/maps/search/?api=1&query=${pharmacy.latitude},${pharmacy.longitude}".toUri()
            startActivity(Intent(Intent.ACTION_VIEW, fallbackUri))
        }
    }

    private fun openPharmacySearchOnMap() {
        if (!hasLocationPermission()) {
            openGenericPharmacySearch()
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location != null) {
                    try {
                        val gmmIntentUri =
                            "geo:${location.latitude},${location.longitude}?q=pharmacy".toUri()
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                        mapIntent.setPackage("com.google.android.apps.maps")
                        startActivity(mapIntent)
                    } catch (_: Exception) {
                        openGenericPharmacySearch()
                    }
                } else {
                    openGenericPharmacySearch()
                }
            }
            .addOnFailureListener { openGenericPharmacySearch() }
    }

    private fun openGenericPharmacySearch() {
        try {
            val gmmIntentUri = "geo:0,0?q=pharmacy".toUri()
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)
        } catch (_: Exception) {
            try {
                val fallbackUri = "https://www.google.com/maps/search/pharmacy".toUri()
                startActivity(Intent(Intent.ACTION_VIEW, fallbackUri))
            } catch (_: Exception) {
                Toast.makeText(this, "Could not open maps", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        if (loading) statusText.visibility = View.GONE
    }

    private fun showStatus(message: String) {
        statusText.text = message
        statusText.visibility = View.VISIBLE
    }
}
