package com.example.healix

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth

/**
 * Centralizes everything related to "who is the current user".
 *
 * Every screen used to read/write a single global SharedPreferences file,
 * which meant two different people logging in on the same device would see
 * each other's data. Now that we have real Firebase accounts, we namespace
 * local storage by the signed-in user's UID so each account stays separate.
 */
object SessionManager {

    private val auth: FirebaseAuth
        get() = FirebaseAuth.getInstance()

    val currentUid: String?
        get() = auth.currentUser?.uid

    val isLoggedIn: Boolean
        get() = auth.currentUser != null

    /** Profile fields (name, age, weight, etc.) collected at sign-up. */
    fun userPrefs(context: Context): SharedPreferences {
        val uid = currentUid ?: "guest"
        return context.getSharedPreferences("HealixUser_$uid", Context.MODE_PRIVATE)
    }

    /** App data such as the medicine list, scoped per account. */
    fun dataPrefs(context: Context): SharedPreferences {
        val uid = currentUid ?: "guest"
        return context.getSharedPreferences("HealixData_$uid", Context.MODE_PRIVATE)
    }

    fun signOut() {
        auth.signOut()
    }
}
