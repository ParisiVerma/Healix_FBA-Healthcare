package com.example.healix

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.text.SimpleDateFormat
import java.util.*

class MedicineListActivity : BaseActivity() {

    private lateinit var listView: ListView
    private lateinit var addBtn: View
    private lateinit var progressText: TextView
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var searchView: SearchView
    private lateinit var list: MutableList<String>
    private lateinit var filteredList: MutableList<String>
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_medicine_list)

        listView = findViewById(R.id.medicineList)
        addBtn = findViewById(R.id.addMedicineBtn)
        progressText = findViewById(R.id.progressText)
        progressBar = findViewById(R.id.progressBar)
        searchView = findViewById(R.id.searchView)

        addBtn.setOnClickListener {
            val intent = Intent(this, AddMedicineActivity::class.java)
            startActivity(intent)
        }

        // ✅ MARK AS TAKEN
        listView.setOnItemClickListener { _, _, position, _ ->
            val originalText = filteredList[position]
            if (!originalText.contains("✅")) {
                val updatedText = originalText + "  ✅ Taken"
                
                // Update in original list
                val originalIndex = list.indexOf(originalText)
                if (originalIndex != -1) {
                    list[originalIndex] = updatedText
                }
                
                saveData()
                loadData()
            }
        }

        // 🗑️ DELETE
        listView.setOnItemLongClickListener { _, _, position, _ ->
            val textToDelete = filteredList[position]
            AlertDialog.Builder(this)
                .setTitle("Delete Medicine")
                .setMessage("Remove this medicine from your tracker?")
                .setPositiveButton("Delete") { _, _ ->
                    list.remove(textToDelete)
                    saveData()
                    loadData()
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }

        // 🔍 SEARCH LOGIC
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                filterList(newText)
                return true
            }
        })
    }

    private fun filterList(query: String?) {
        filteredList = if (query.isNullOrEmpty()) {
            list.toMutableList()
        } else {
            list.filter { it.contains(query, ignoreCase = true) }.toMutableList()
        }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, filteredList)
        listView.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        checkAndResetDaily()
        loadData()
    }

    private fun checkAndResetDaily() {
        val sharedPref = SessionManager.dataPrefs(this)
        val lastDate = sharedPref.getString("lastDate", "")
        val today = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())

        if (lastDate != today) {
            val data = sharedPref.getString("medList", "")
            if (!data.isNullOrEmpty()) {
                val updatedList = data.split("||").map {
                    it.replace("  ✅ Taken", "")
                }
                val updatedData = updatedList.joinToString("||")
                sharedPref.edit()
                    .putString("medList", updatedData)
                    .putString("lastDate", today)
                    .apply()
            } else {
                sharedPref.edit().putString("lastDate", today).apply()
            }
        }
    }

    private fun loadData() {
        val sharedPref = SessionManager.dataPrefs(this)
        val data = sharedPref.getString("medList", "")

        list = if (!data.isNullOrEmpty()) {
            data.split("||").toMutableList()
        } else {
            mutableListOf()
        }
        
        filterList(searchView.query?.toString())
        updateProgress()
    }

    private fun saveData() {
        val sharedPref = SessionManager.dataPrefs(this)
        val updated = list.joinToString("||")
        sharedPref.edit().putString("medList", updated).apply()
    }

    private fun updateProgress() {
        val total = list.size
        val taken = list.count { it.contains("✅") }

        if (total > 0) {
            val percent = (taken * 100) / total
            progressText.text = "Daily Progress: $taken/$total completed"
            progressBar.progress = percent
        } else {
            progressText.text = "No medicines added yet"
            progressBar.progress = 0
        }
    }
}