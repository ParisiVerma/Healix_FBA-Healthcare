package com.example.healix

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.net.toUri
import androidx.core.widget.NestedScrollView
import java.util.Locale

class ProfileActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_profile)

        val sharedPref = SessionManager.userPrefs(this)

        val userName = sharedPref.getString("username", "User") ?: "User"
        val weightStr = sharedPref.getString("weight", "") ?: ""
        val heightStr = sharedPref.getString("height", "") ?: ""
        val ageStr = sharedPref.getString("age", "") ?: ""
        val genderStr = sharedPref.getString("gender", "") ?: ""
        val bloodStr = sharedPref.getString("blood", "") ?: ""

        findViewById<TextView>(R.id.welcomeName).text = getString(R.string.welcome_back, userName)
        
        findViewById<TextView>(R.id.nameText).text = getString(R.string.full_name, userName)
        findViewById<TextView>(R.id.ageText).text = getString(R.string.age_label, ageStr)
        findViewById<TextView>(R.id.genderText).text = getString(R.string.gender_label, genderStr)
        findViewById<TextView>(R.id.weightText).text = getString(R.string.weight_label, weightStr)
        findViewById<TextView>(R.id.bloodText).text = getString(R.string.blood_group_label, bloodStr)

        // ⚖️ BMI CALCULATION
        calculateAndDisplayBMI(weightStr, heightStr)

        // 🌐 OPEN GOOGLE LINKS
        findViewById<Button>(R.id.hrBtn).setOnClickListener {
            openLink("https://www.google.com/search?q=ideal+heart+rate")
        }

        findViewById<Button>(R.id.bpBtn).setOnClickListener {
            openLink("https://www.google.com/search?q=ideal+blood+pressure")
        }

        findViewById<Button>(R.id.sugarBtn).setOnClickListener {
            openLink("https://www.google.com/search?q=normal+blood+sugar")
        }

        // ❤️ HEALTH ADVISORY QUICK ACTION (Scrolls to detail section)
        findViewById<View>(R.id.advisoryCardBtn).setOnClickListener {
            val scrollView = findViewById<NestedScrollView>(R.id.dashboardScroll)
            val targetView = findViewById<View>(R.id.advisorySectionTitle)
            scrollView.post {
                scrollView.smoothScrollTo(0, targetView.top)
            }
        }

        // 🩺 SYMPTOM CHECKER
        findViewById<View>(R.id.symptomBtn).setOnClickListener {
            startActivity(Intent(this, SymptomCheckerActivity::class.java))
        }

        // 🏥 NEARBY MEDICAL STORES
        findViewById<View>(R.id.storesBtn).setOnClickListener {
            startActivity(Intent(this, MedicalStoresActivity::class.java))
        }

        // 💊 MEDICINE TRACKER
        findViewById<View>(R.id.docBtn).setOnClickListener {
            startActivity(Intent(this, MedicineListActivity::class.java))
        }

        // 🚪 LOGOUT
        findViewById<ImageButton>(R.id.logoutBtn).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Log out")
                .setMessage("Are you sure you want to log out of Healix?")
                .setPositiveButton("Log out") { _, _ ->
                    SessionManager.signOut()
                    startActivity(
                        Intent(this, WelcomeActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    )
                    finish()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun calculateAndDisplayBMI(weightStr: String, heightStr: String) {
        val bmiText = findViewById<TextView>(R.id.bmiText)
        val weightStatusText = findViewById<TextView>(R.id.weightStatusText)
        
        try {
            val weight = weightStr.toFloat()
            val heightCm = heightStr.toFloat()
            
            if (heightCm > 0) {
                val heightM = heightCm / 100
                val bmi = weight / (heightM * heightM)
                
                val category = when {
                    bmi < 18.5 -> "Underweight"
                    bmi < 25 -> "Normal"
                    bmi < 30 -> "Overweight"
                    else -> "Obese"
                }
                
                bmiText.text = String.format(Locale.getDefault(), "%.1f", bmi)
                weightStatusText.text = category
            } else {
                bmiText.text = "--"
                weightStatusText.text = getString(R.string.invalid_height)
            }
        } catch (_: Exception) {
            bmiText.text = "--"
            weightStatusText.text = getString(R.string.set_weight_height)
        }
    }

    private fun openLink(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, url.toUri())
        startActivity(intent)
    }
}
