package com.example.healix

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.cardview.widget.CardView

class SymptomCheckerActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_symptom_checker)

        val input = findViewById<EditText>(R.id.symptomInput)
        val analyzeBtn = findViewById<Button>(R.id.analyzeBtn)
        val resultCard = findViewById<CardView>(R.id.resultCard)
        val resultTitle = findViewById<TextView>(R.id.resultTitle)
        val resultDescription = findViewById<TextView>(R.id.resultDescription)

        analyzeBtn.setOnClickListener {
            val text = input.text.toString().lowercase()

            if (text.isEmpty()) {
                Toast.makeText(this, "Please describe your symptoms", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 🧠 IMPROVISED PRACTICAL ANALYSIS
            val (title, description) = when {
                text.contains("chest pain") || text.contains("shortness of breath") -> {
                    "URGENT: Immediate Medical Attention Required" to 
                    "Severe symptoms detected. Please contact emergency services or visit the nearest hospital immediately. Do not drive yourself."
                }
                text.contains("fever") && (text.contains("cough") || text.contains("throat")) -> {
                    "Potential Viral Respiratory Infection" to 
                    "Common in flu or cold. Rest, stay hydrated, and monitor your temperature. If fever exceeds 103°F (39.4°C) or lasts more than 3 days, consult a doctor."
                }
                text.contains("headache") && text.contains("vision") -> {
                    "Migraine or Vision-Related Issue" to 
                    "A severe headache with vision changes should be evaluated. Try resting in a dark, quiet room. Seek medical advice if it persists."
                }
                text.contains("stomach") || text.contains("nausea") || text.contains("pain") && text.contains("abdomen") -> {
                    "Gastrointestinal Distress" to 
                    "Could be related to food intake or a minor infection. Stick to a bland diet (BRAT) and stay hydrated. If pain is localized or sharp, see a professional."
                }
                text.contains("rash") || text.contains("itch") -> {
                    "Dermatological Concern" to 
                    "Could be an allergic reaction or localized skin irritation. Avoid scratching and monitor if the rash spreads or if you experience swelling."
                }
                text.contains("fatigue") || text.contains("tired") -> {
                    "General Fatigue" to 
                    "Often caused by lack of sleep, dehydration, or stress. Ensure 7-9 hours of sleep and adequate water intake. If it lasts weeks, blood tests may be needed."
                }
                else -> {
                    "General Health Consultation Recommended" to 
                    "Your symptoms are broad. We recommend keeping a symptom diary and scheduling a routine check-up with your primary physician."
                }
            }

            // Update UI
            resultTitle.text = title
            resultDescription.text = description
            resultCard.visibility = View.VISIBLE
            
            // Hide keyboard (optional but better UX)
            input.clearFocus()
        }
    }
}