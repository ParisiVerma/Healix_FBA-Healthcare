package com.example.healix

data class Pharmacy(
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val distanceMeters: Double?,
    val openNow: Boolean?
)
