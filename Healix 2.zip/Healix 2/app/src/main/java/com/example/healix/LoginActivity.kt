package com.example.healix

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()

        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val loginBtn = findViewById<Button>(R.id.loginBtn)
        val progress = findViewById<ProgressBar>(R.id.loginProgress)
        val forgotPasswordLink = findViewById<TextView>(R.id.forgotPasswordLink)
        val goToSignUpLink = findViewById<TextView>(R.id.goToSignUpLink)

        loginBtn.setOnClickListener {
            val userEmail = email.text.toString().trim()
            val userPassword = password.text.toString()

            if (!Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()) {
                email.error = "Enter a valid email"
                return@setOnClickListener
            }

            if (userPassword.isEmpty()) {
                password.error = "Enter your password"
                return@setOnClickListener
            }

            setLoading(true, loginBtn, progress)

            auth.signInWithEmailAndPassword(userEmail, userPassword)
                .addOnCompleteListener { task ->
                    setLoading(false, loginBtn, progress)

                    if (task.isSuccessful) {
                        startActivity(Intent(this, ProfileActivity::class.java))
                        finish()
                    } else {
                        val message = when (task.exception) {
                            is FirebaseAuthInvalidUserException,
                            is FirebaseAuthInvalidCredentialsException ->
                                "Incorrect email or password"
                            else -> task.exception?.localizedMessage
                                ?: "Login failed. Please try again."
                        }
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    }
                }
        }

        forgotPasswordLink.setOnClickListener {
            showForgotPasswordDialog(email.text.toString().trim())
        }

        goToSignUpLink.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }

    private fun showForgotPasswordDialog(prefilledEmail: String) {
        val input = EditText(this).apply {
            hint = "Your email address"
            setText(prefilledEmail)
        }

        AlertDialog.Builder(this)
            .setTitle("Reset Password")
            .setMessage("We'll send a password reset link to your email.")
            .setView(input)
            .setPositiveButton("Send") { _, _ ->
                val resetEmail = input.text.toString().trim()
                if (!Patterns.EMAIL_ADDRESS.matcher(resetEmail).matches()) {
                    Toast.makeText(this, "Enter a valid email first", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                auth.sendPasswordResetEmail(resetEmail)
                    .addOnCompleteListener { task ->
                        val message = if (task.isSuccessful) {
                            "Reset link sent! Check your inbox."
                        } else {
                            task.exception?.localizedMessage ?: "Couldn't send reset email."
                        }
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setLoading(loading: Boolean, button: Button, progress: ProgressBar) {
        button.isEnabled = !loading
        progress.visibility = if (loading) View.VISIBLE else View.GONE
    }
}
